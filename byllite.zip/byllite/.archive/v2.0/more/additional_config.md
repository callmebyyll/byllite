## Additional Configuration

- [API Keys](api_keys.md) (for Basic search)
- [Phoneinfoga Setup](phoneinfoga.md) (for Phoneinfoga scan)
- [Truecaller Account](truecaller.md) (for Truecaller scan)

<br>
<hr>
<br>

> Note : click on the any of the above options to see how to configure it.
