__project__ = 'ph0mber'
__version__ = '3.0'

__dev__ = 's41r4j'

__website__ = 'https://github.com/phomber'
__twitter__ = 'https://twitter.com/s41r4j'
__instagram__ = 'https://instagram.com/s41r4j'
